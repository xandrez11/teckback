package br.com.fujideia.iesp.tecback.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class FeingConfig {
}
